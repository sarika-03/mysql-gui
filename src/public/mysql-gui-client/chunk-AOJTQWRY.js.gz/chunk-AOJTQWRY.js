import{Q as a}from"./chunk-FTSG4FEG.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
