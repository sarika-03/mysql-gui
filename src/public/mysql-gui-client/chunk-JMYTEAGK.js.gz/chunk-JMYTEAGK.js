import{W as a}from"./chunk-NTRXMUUW.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
