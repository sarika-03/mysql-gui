import{W as a}from"./chunk-6KN5RVFH.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
