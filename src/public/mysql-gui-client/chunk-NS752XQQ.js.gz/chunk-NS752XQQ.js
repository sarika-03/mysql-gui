import{S as a}from"./chunk-L5M2WUSY.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
