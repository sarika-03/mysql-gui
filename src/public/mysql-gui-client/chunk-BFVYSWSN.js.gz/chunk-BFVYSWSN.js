import{V as a}from"./chunk-KRBH7G6D.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
