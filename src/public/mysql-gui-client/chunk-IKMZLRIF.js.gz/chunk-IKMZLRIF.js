import{W as a}from"./chunk-HFPFZL2X.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
