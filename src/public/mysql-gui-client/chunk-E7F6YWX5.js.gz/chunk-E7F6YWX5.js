import{Q as a}from"./chunk-RWYG4YRZ.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
