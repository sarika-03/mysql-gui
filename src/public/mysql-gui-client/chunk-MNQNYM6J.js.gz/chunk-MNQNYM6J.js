import{W as a}from"./chunk-VWQAU6PE.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
