import{W as a}from"./chunk-BFSBQYDF.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
