import{Q as a}from"./chunk-OTNF7MVG.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
