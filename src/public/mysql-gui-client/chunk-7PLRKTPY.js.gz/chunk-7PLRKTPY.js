import{W as a}from"./chunk-SF5AYN2C.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
