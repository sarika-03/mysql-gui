import{W as a}from"./chunk-ROWPX2PD.js";import"./chunk-LYBDN2BO.js";export{a as HomeComponent};
