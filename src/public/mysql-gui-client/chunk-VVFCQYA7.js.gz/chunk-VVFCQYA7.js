import{e as o}from"./chunk-LYBDN2BO.js";var t=[{path:"",title:"Home",loadComponent:()=>o(void 0,null,function*(){return(yield import("./chunk-7PLRKTPY.js")).HomeComponent})}];export{t as routes};
