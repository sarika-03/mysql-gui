import{c as o}from"./chunk-YGFNLDZQ.js";var t=[{path:"",title:"Home",loadComponent:()=>o(void 0,null,function*(){return(yield import("./chunk-F6N7BNAT.js")).HomeComponent})}];export{t as routes};
